import React from "react";

export default function App() {
  return (
    <div className="font-sans text-slate-900 bg-slate-50">
      {/* Header */}
      <header className="sticky top-0 bg-white/90 backdrop-blur border-b border-slate-200 shadow-sm z-50">
        <div className="max-w-6xl mx-auto flex items-center justify-between h-16 px-6">
          <div
            className="font-bold text-lg flex items-center gap-2 cursor-pointer"
            onClick={() =>
              document.getElementById("start")?.scrollIntoView({ behavior: "smooth" })
            }
          >
            <svg
              width="22"
              height="22"
              viewBox="0 0 24 24"
              fill="none"
              aria-hidden
            >
              <path
                d="M3 11.5L12 4l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1V11.5z"
                fill="currentColor"
              />
            </svg>
            Tgèsa Palits – Zimmermann
          </div>
          <nav className="flex gap-3">
            <button
              className="px-3 py-1.5 rounded-lg hover:bg-slate-100"
              onClick={() =>
                document.getElementById("willkommen")?.scrollIntoView({ behavior: "smooth" })
              }
            >
              Willkommen
            </button>
            <button
              className="px-3 py-1.5 rounded-lg hover:bg-slate-100"
              onClick={() =>
                document.getElementById("galerie")?.scrollIntoView({ behavior: "smooth" })
              }
            >
              Galerie
            </button>
            <a
              className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-blue-600 text-white font-semibold shadow hover:-translate-y-0.5 hover:shadow-lg transition"
              href="#kontakt"
            >
              Kontakt
            </a>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section
        id="start"
        className="relative h-[90vh] grid place-items-center text-center text-white"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1482192505345-5655af888cc4?auto=format&fit=crop&w=1600&q=60')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-black/50" />
        <div className="relative z-10 max-w-2xl px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">Herzlich Willkommen</h1>
          <p className="text-lg opacity-90">Entdecken Sie unser Zuhause in Sedrun</p>
          <div className="mt-6 flex flex-wrap gap-4 justify-center">
            <a
              className="px-6 py-2 rounded-full bg-blue-600 text-white font-semibold shadow hover:-translate-y-0.5 hover:shadow-lg transition"
              href="https://www.airbnb.ch"
              target="_blank"
            >
              Jetzt buchen
            </a>
            <button
              className="px-6 py-2 rounded-full bg-blue-600 text-white font-semibold shadow hover:-translate-y-0.5 hover:shadow-lg transition"
              onClick={() =>
                document.getElementById("willkommen")?.scrollIntoView({ behavior: "smooth" })
              }
            >
              Mehr erfahren
            </button>
          </div>
        </div>
      </section>

      {/* Willkommen */}
      <section id="willkommen" className="max-w-6xl mx-auto px-6 py-20 grid md:grid-cols-2 gap-8 items-center">
        <div className="rounded-2xl overflow-hidden shadow-lg h-[380px]">
          <img
            src="https://images.unsplash.com/photo-1519681393784-d120267933ba"
            alt="Ferienwohnung – Sedrun"
            className="w-full h-full object-cover"
          />
        </div>
        <div>
          <h2 className="text-3xl font-bold mb-4">Entdecken Sie Unser Zuhause</h2>
          <p>
            Tgèsa Palits – Zimmermann ist eine frisch renovierte Ferienwohnung in
            Sedrun. Mit Balkon und herrlicher Aussicht bietet sie den perfekten
            Rückzugsort – nur wenige Schritte vom Skigebiet, Bahnhof sowie
            Restaurants und Supermärkten entfernt.
          </p>
          <div className="flex flex-wrap gap-2 mt-4">
            {["Nahe Skigebiet", "WLAN", "Smart-TV", "Komfortable Betten", "Balkon & Aussicht"].map(
              (feature) => (
                <div
                  key={feature}
                  className="px-3 py-1 rounded-full bg-yellow-400 text-black text-sm font-semibold"
                >
                  {feature}
                </div>
              )
            )}
          </div>
        </div>
      </section>

      {/* Galerie */}
      <section id="galerie" className="max-w-6xl mx-auto px-6 py-20">
        <h2 className="text-3xl font-bold mb-6">Galerie</h2>
        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          {[
            "https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1200&q=60",
            "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1200&q=60",
            "https://images.unsplash.com/photo-1523419409543-8f8d7fdc9766?auto=format&fit=crop&w=1200&q=60",
            "https://images.unsplash.com/photo-1491553895911-0055eca6402d?auto=format&fit=crop&w=1200&q=60",
          ].map((src, i) => (
            <img
              key={i}
              src={src}
              alt={`Foto ${i + 1}`}
              className="w-full h-64 object-cover rounded-xl shadow hover:scale-105 transition"
            />
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer id="kontakt" className="bg-slate-900 text-white py-16">
        <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-10 items-start">
          <div>
            <h2 className="text-2xl font-bold mb-4">Kontakt</h2>
            <p>
              <strong>Tgèsa Palits - Zimmermann</strong>
              <br />Via Valtgeva 3
              <br />7188 Sedrun GR
            </p>
            <p className="mt-2">Fam. Zimmermann<br />5037 Muhen</p>
            <p className="mt-2">
              <a href="tel:+41792377443" className="text-yellow-400 font-semibold">
                +41 79 237 7443
              </a>
              <br />
              <a
                href="mailto:sedrun@zworld.ch"
                className="text-yellow-400 font-semibold"
              >
                sedrun@zworld.ch
              </a>
            </p>
          </div>
          <div className="rounded-2xl bg-white text-slate-900 shadow-lg p-6">
            <h3 className="text-xl font-bold mb-2">Direkt anfragen</h3>
            <p className="mb-4">
              Senden Sie uns eine E-Mail mit Ihrem gewünschten Zeitraum und Anzahl
              Gäste.
            </p>
            <a
              className="px-6 py-2 rounded-full bg-blue-600 text-white font-semibold shadow hover:-translate-y-0.5 hover:shadow-lg transition"
              href="mailto:sedrun@zworld.ch?subject=Anfrage%20Tg%C3%A8sa%20Palits"
            >
              E-Mail schreiben
            </a>
          </div>
        </div>
        <div className="text-center mt-10 text-sm opacity-80">
          © {new Date().getFullYear()} Tgèsa Palits - Zimmermann
        </div>
      </footer>
    </div>
  );
}
